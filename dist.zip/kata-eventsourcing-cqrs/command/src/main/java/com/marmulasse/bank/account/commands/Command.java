package com.marmulasse.bank.account.commands;

public interface Command {
}
