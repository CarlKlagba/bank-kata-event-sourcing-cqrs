package com.marmulasse.bank.query.account.queries;

public interface Query {

    Class thatReturn();
}
