package com.marmulasse.bank.query.account.events;

public interface AccountEvent {

}
